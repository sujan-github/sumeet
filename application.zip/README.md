# Sumeet

An angular 5 and php codeigniter project with Rest api.

# Angular 5
Install the latest angular-cli and run "ng build" command from the .../sumeet/angular path.
